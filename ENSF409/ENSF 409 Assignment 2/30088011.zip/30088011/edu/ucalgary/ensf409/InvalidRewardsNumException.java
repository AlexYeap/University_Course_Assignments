package edu.ucalgary.ensf409;
import java.lang.Exception;
public class InvalidRewardsNumException extends Exception {
    public InvalidRewardsNumException(){
        super("InvalidRewardsNumException");
    }

}
