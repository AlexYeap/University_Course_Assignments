package edu.ucalgary.ensf409;


enum Actions{
    FORWARD,
    LEFT,
    REVERSE,
    RIGHT,
    START,
    STOP, 
};

