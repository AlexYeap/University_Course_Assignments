package edu.ucalgary.ensf409;

interface FormattedOutput {
    String getFormatted();
    
}
